(function(){let e=0;function n(){let o=setTimeout(()=>{const t=document.querySelector(".translate-tab-container .tab-body");if(t)t.style.position="fixed",t.style.zIndex="2000",t.style.inset="0",e=0,clearTimeout(o);else{if(e++,e>6){e=0;return}n()}},500)}window.addEventListener("load",()=>{n()});
})()
