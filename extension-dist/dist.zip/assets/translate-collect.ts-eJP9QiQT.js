import{i as v,a as T,g as B}from"./index-cG_EJwWf.js";import{c as L}from"./index-hnLra4uH.js";import{d as w,o as S,h as E,j as I,n as c,a as d,e as p,k as u,t as y,u as r,l as D,r as q}from"./runtime-dom.esm-bundler-DI_B6Rga.js";const z=["width","height"],P=w({__name:"cancel-icon",props:{color:{type:String,default:""},width:{type:String,default:"1em"},height:{type:String,default:"1em"},className:{type:String,default:""}},setup(t){return(e,o)=>(S(),E("svg",{class:c(`svg-icon ${t.className}`),style:I({color:t.color,width:t.width,height:t.height}),width:t.width,height:t.height,xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 1024 1024"},[...o[0]||(o[0]=[d("path",{fill:"currentColor",d:"M764.288 214.592 512 466.88 259.712 214.592a31.936 31.936 0 0 0-45.12 45.12L466.752 512 214.528 764.224a31.936 31.936 0 1 0 45.12 45.184L512 557.184l252.288 252.288a31.936 31.936 0 0 0 45.12-45.12L557.12 512.064l252.288-252.352a31.936 31.936 0 1 0-45.12-45.184z"},null,-1)])],14,z))}}),R="_popup_1gn4j_1",X="_successful_1gn4j_30",A="_failure_1gn4j_33",l={"notification-box":"_notification-box_1gn4j_1",popup:R,successful:X,failure:A,"cancel-icon":"_cancel-icon_1gn4j_36"},M=["id"],O=w({__name:"notification-box",props:{notificationType:{}},setup(t){const e=q(!0);return(o,n)=>p((S(),E("div",{id:r(l)["notification-box"]},[p(d("h3",{class:c(r(l).successful)},y(o.$t("add_vocabulary.successful")),3),[[u,t.notificationType==="successful"]]),p(d("h3",{class:c(r(l).failure)},y(o.$t("add_vocabulary.failure")),3),[[u,t.notificationType==="failure"]]),p(d("h3",{class:c(r(l).failure)},y(o.$t("add_vocabulary.emptyBook")),3),[[u,t.notificationType==="emptyBook"]]),d("span",{onClick:n[0]||(n[0]=i=>e.value=!1),class:c(r(l)["cancel-icon"])},[D(P,{width:"25px",height:"25px"})],2)],8,M)),[[u,e.value]])}}),V="@keyframes _popup_1gn4j_1{0%{transform:translate(310px)}to{transform:translate(0)}}#_notification-box_1gn4j_1 h3{padding:0;margin:0;font-size:15px}#_notification-box_1gn4j_1{position:fixed;top:50px;right:10px;width:300px;z-index:10000;height:auto;background-color:#fff;box-shadow:0 2px 10px #0003;border-radius:8px;padding:10px 15px;animation:_popup_1gn4j_1 .5s linear;display:flex;justify-content:space-between;align-items:center}#_notification-box_1gn4j_1 ._successful_1gn4j_30{color:#67c23a}#_notification-box_1gn4j_1 ._failure_1gn4j_33{color:#f56c6c}#_notification-box_1gn4j_1 ._cancel-icon_1gn4j_36{cursor:pointer}",g=t=>v.global.t(t);function F(t){if(t.id)return`//*[@id="${t.id}"]`;const e=[];for(;t&&t.nodeType===Node.ELEMENT_NODE;){if(t.id){e.unshift(`//*[@id="${t.id}"]`);break}let o=1,n=t.previousElementSibling;for(;n;)n.tagName===t.tagName&&o++,n=n.previousElementSibling;e.unshift(`${t.tagName.toLowerCase()}[${o}]`),t=t.parentNode}return e.join("/")}function k(t,e,o,n){if(!t)return;const i=document.evaluate(t,document,null,XPathResult.FIRST_ORDERED_NODE_TYPE,null).singleNodeValue;W({...n||{},element:i,vocabulary:e,isOpen:o})}function W({element:t,vocabulary:e,translations:o="",examples:n="",isOpen:i=!1}){console.log("vocabulary11",e),t.innerHTML=t.innerHTML.replaceAll(e,`
            <span class="diy-popover-word">
                <details ${i?"open":""}>
                    <summary>${e}</summary>
                    <form class="diy-popover-box">
                        <input class="translations" value="${o}" placeholder="${g("collect_words.translation_ph")}"/>
                        <input class="examples" value="${n}" placeholder="${g("collect_words.examples_ph")}"/>
                        <button style='display: none;' type="submit">Submit</button>
                        <span style="color: #fff;font-size: 13px;"><b style="color: #ff0000;">*</b>${g("collect_words.submit")}</span>
                    </form>
                </details>
            </span>
        `),t.querySelectorAll(".diy-popover-word").forEach(a=>{const s=a.querySelector(".diy-popover-box"),b=a.querySelector("details");s&&s.addEventListener("submit",m=>{m.preventDefault();const $=m.target.querySelector(".translations").value,N=m.target.querySelector(".examples").value;console.log("translations",$),console.log("examples",N),b&&(b.open=!1)})})}function H(){let t=document.getElementById("diy-style");t||(t=document.createElement("style"),t.id="diy-popover-style",document.head.appendChild(t)),t.textContent=`
        .diy-popover-word {
            position: relative;
            display: inline-block;
            background: #1ABC9C;
            border-radius: 4px;
            padding: 2px 4px;
            color: #333;
        }
        .diy-popover-word details {
            background: #1ABC9C;
            padding:0 !important;
            margin:0 !important;
        }
        .diy-popover-word summary {
            list-style: none; /* hide the default arrow */
            cursor: pointer;
            padding:0 !important;
            margin:0 !important;
        }

        .diy-popover-word summary::-webkit-details-marker {
            display: none; /* hide arrow in Chrome/Safari */
        }

        .diy-popover-box {
            min-width: 150px;
            width:95%;
            visibility: visible;
            opacity: 0;
            position: absolute;
            bottom: 120%;
            left: 50%;
            transform: translateX(-50%);
            color: #333;
            padding: 5px 8px;
            border-radius: 6px;
            white-space: nowrap;
            z-index: 10;
            pointer-events: none;
            transition: opacity 0.2s;
            background: rgba(26, 188, 156, 0.8);
        }
        .diy-popover-box input{
            display: block;
            width: auto;
            margin-bottom: 5px;
            padding: 4px;
        }
        .diy-popover-word .diy-popover-box {
            visibility: visible;
            opacity: 1;
            pointer-events: auto;
        }
    `}function U(){document.addEventListener("click",t=>{document.querySelectorAll(".diy-popover-word").forEach(o=>{if(!o.contains(t.target)){const n=o.querySelector("details");n&&(n.open=!1)}})})}const x="diy-notification-box";let f=null;const h=t=>{f&&clearTimeout(f),L({document,eleId:x,component:O,props:{notificationType:t},styleCss:V,plugins:[v]}),f=setTimeout(()=>{document.getElementById(x)?.remove(),f=null},3.5*1e3)};let C=null,_=!1;document.addEventListener("contextmenu",t=>{C=t.target||null});function j(){if(_)return;let t=null;t=setTimeout(()=>{_=!0,H(),U();const e=decodeURIComponent(location.href.toString());B({SourceWeb:e}).then(o=>{(o.payload||[]).forEach(i=>{k(i.XPath,i.vocabulary,!1,i)})}),clearTimeout(t),t=null},1e3)}window.addEventListener("load",()=>{j()});document.readyState==="complete"&&(console.log("readyState"),j());chrome.runtime.onMessage.addListener(async t=>{if(t.action==="translate-collect"){console.log("message",t);const e=t.text,o=await chrome.storage.sync.get("bookChapterId");console.log("result",o);const n=JSON.parse(o.bookChapterId),i=n[0],a=n[1];if(!a||!i){h("emptyBook");return}if(!e.trim())return;let s=F(C);k(s,e,!0),T({bookId:i,chapterId:a,vocabulary:e,translations:"",examples:"",SourceWeb:decodeURIComponent(location.href.toString()),XPath:s}).then(()=>{h("successful")}).catch(()=>{h("failure")})}});
